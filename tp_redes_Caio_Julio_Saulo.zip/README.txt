implementado com python 3.6.5
necessita da biblioteca ffprobe3:
  execute o comando : ` pip install ffprobe3 --user ` ou ` pip3 install ffprobe3 --user ` 
