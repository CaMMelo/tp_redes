python3 run_server.py 2000 &
python3 run_client.py '127.0.0.1' 2000 $1 | mpv -
